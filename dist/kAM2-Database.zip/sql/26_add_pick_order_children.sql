-- ============================================================================
-- 26 - TWO CHILD TABLES THE DATA-MODEL ANALYSIS FOUND MISSING
-- ============================================================================
-- Adds ObjectSpec rows to sets that already exist and are already tested.
-- No new process, no new key, no change to any cutoff or gate - so the existing
-- test evidence for those sets stays valid and only the new tables need proving.
--
--   t_pick_container  -> AAD_ORDER_ARCH       NO LONGER ADDED - see section 1.
--                                             It has FK children the set cannot
--                                             express, and no FK to t_order.
--   t_pick_task_uom   -> AAD_PICKDETAIL_ARCH  joined on (pick_id)
--
-- Revised 2026-09-16. Earlier revisions added t_pick_container at DeleteOrder
-- 45; on real data the delete fails on the FK from t_container_detail /
-- t_container_station. 57_order_set_container_family.sql removes it from an
-- instance where this script already ran.
--
-- WHY THESE TWO, AND NOT THE OTHER FIFTY-ONE CANDIDATES
--
-- The supplied data models (WA-1cast, WA-2cast, AAD-Notify) document every
-- parent-child relation of the five configured sets, and every one of them was
-- already configured. But those models cover only 185 of AAD's 394 tables, and
-- five of our own fourteen tables appear in NO model at all (t_allocation,
-- t_work_q + its two children, ADV.t_log_message). AAD also has just 217 foreign
-- keys, and t_work_q and t_allocation have none - so parent-child logic here is
-- mostly LOGICAL, expressed as shared key columns rather than declared.
--
-- Searching on shared key columns produced 53 candidates. They were then filtered
-- on one question that decides the matter: DOES THE APPLICATION DELETE IT ITSELF?
-- A table the WMS purges needs no retention from us, and archiving it would race
-- the application's own logic. That test eliminated almost everything:
--   * t_tran_log_holding (+ _reason, _sn) - usp_process_tran_log is a drain loop:
--     it takes MAX(tran_log_holding_id) as a high-water mark, copies the rows into
--     t_tran_log, then DELETEs everything <= that mark with no filter at all, and
--     loops until the table is empty. Its rows are transactions IN FLIGHT.
--   * the cartonisation/optimiser family (t_cartonize_results,
--     t_container_optimize_block/status/xml) - usp_cartonize_q and
--     usp_afa_hold_shipment delete them by cartonization_batch_id; usp_cartonize_q
--     even runs our exact candidate predicate itself.
--   * t_sto_attrib_collection_master - has a detail_checksum column and is
--     referenced by nine tables including t_stored_item (live inventory) and
--     t_bom_detail. It is a content-deduplicated shared pool, not a child.
--   * master and configuration data - t_item_uom (88 referencing modules),
--     t_pick_put_master/detail, t_employee, t_item_master. Note that pick_put_id
--     is a pick/put PROFILE, a different concept from pick_id.
--
-- The two tables below survived that filter: nothing in the WMS deletes them on
-- the normal path, they carry the anchor key, and they are document-scoped.
--
-- NOT DONE HERE, DELIBERATELY: t_order_manifest also survived, but it needs a
-- third key (order_id) added to the ORDER key spec and it is a heap with no index
-- at all, so its delete join would scan the whole table every batch. Small
-- benefit, largest blast radius - left out until someone asks for it.
-- ============================================================================
:setvar AdminDb "kArchiveManagerAdmin"
:setvar WmsDb "AAD"

:on error exit

USE [$(AdminDb)];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* ---------------------------------------------------------------------------
   Refuse to run against a configuration that does not have the two parent sets,
   and refuse if the source tables are not there. A missing table would otherwise
   be discovered later as a validation warning rather than now as a clear stop.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM arch.Process WHERE ProcessCode = N'AAD_ORDER_ARCH')
    THROW 60700, 'AAD_ORDER_ARCH does not exist - run 04_seed_order.sql / 25_seed_document_sets.sql first.', 1;
IF NOT EXISTS (SELECT 1 FROM arch.Process WHERE ProcessCode = N'AAD_PICKDETAIL_ARCH')
    THROW 60701, 'AAD_PICKDETAIL_ARCH does not exist - run 20_seed_standalone.sql first.', 1;
GO

DECLARE @missing nvarchar(max) = N'';
DECLARE @chk nvarchar(max) = N'
SELECT @out = STUFF((SELECT N'', '' + t.n FROM (VALUES (N''t_pick_container''), (N''t_pick_task_uom'')) AS t(n)
                     WHERE NOT EXISTS (SELECT 1 FROM ' + QUOTENAME(N'$(WmsDb)') + N'.sys.tables st
                                       WHERE st.name = t.n COLLATE DATABASE_DEFAULT)
                     FOR XML PATH('''')), 1, 2, '''');';
EXEC sys.sp_executesql @chk, N'@out nvarchar(max) OUTPUT', @out = @missing OUTPUT;

IF @missing IS NOT NULL AND @missing <> N''
BEGIN
    PRINT 'Missing in $(WmsDb): ' + @missing;
    THROW 60702, 'A source table this script configures does not exist. Nothing was changed.', 1;
END
ELSE
    PRINT 'Both source tables are present in $(WmsDb).';
GO

/* ===========================================================================
   1) t_pick_container -> AAD_ORDER_ARCH
   ===========================================================================
   A container is a per-order carton instance: 31 columns of shipping fact -
   tracking_number, bol_number, freight_cost, manifest_status, actual_ship_date,
   plus print_data nvarchar(max). Created per document by usp_allocate and
   usp_bpk_create_container_record.

   IT BELONGS TO THE ORDER, NOT TO THE PICK. It carries a single order_number and
   is shared across many picks of the same order, which is why the application's
   own removal path (usp_afa_remove_line_data) deletes a container only when NO
   pick of that order still references it. Order-granularity archiving reproduces
   that semantics; pick-granularity would break it.

   NOTHING PURGES IT ON THE SHIP PATH - VERIFIED, NOT ASSUMED. A pattern search
   for DELETE near the table name lists usp_shp_tx, which would have made this a
   self-managed table. Reading the procedure disproves it: usp_shp_tx mentions
   t_pick_container only at lines 282 and 463, both LEFT OUTER JOIN ... WITH
   (NOLOCK), and its four DELETEs target serial numbers, t_stored_item,
   t_hu_master and t_work_q_assignment. Every DELETE of t_pick_container in the
   database is an undo or hold path (usp_afa_remove_*, usp_afo_remove_*,
   usp_*_hold_*, usp_replan_allocated_picks). Containers of shipped orders are
   never removed.

   DeleteOrder 45: after t_pack (40), before the anchor t_order (50). The anchor
   is always deleted last, so anything joined to it must precede it.

   ONE ACCEPTED LIMITATION: order_number is NULLABLE on this table. A container
   with no order can never match the predicate and is left in place. That is the
   safe direction - we never delete a row we cannot attribute - but it does mean
   the table is not fully drained by this set. Rows in that state need a separate
   answer if they turn out to be common on a live instance.

   WHAT THE ANALYSIS ABOVE MISSED - AND WHY THIS SECTION NO LONGER ADDS THE TABLE
   (2026-09-16)

   Everything above about the WMS *procedures* is true and was verified. What it
   did not look at is sys.foreign_keys. Three tables carry an enforced, trusted
   foreign key INTO t_pick_container on (wh_id, container_id):

       t_container_detail    FK since 2024-02, 1 443 rows on the reference data
       t_container_station   FK since 2024-01,   711 rows
       t_container_master    FK since 2024-01, 1 010 rows

   Deleting a container while any of them still references it fails on the FK.
   The throughput tests never hit this because the seeded containers (KAMTC-B%)
   had no children; the first run on real data did, and 506 containers of
   archive-eligible orders had such children.

   t_container_master has order_number and joins to the ORDER set plainly - it is
   added by 57 and belongs at DeleteOrder 43. The other two DO NOT have
   order_number; their only path to the order is through t_pick_container, and
   the runtime builds  DELETE t ... INNER JOIN #Keys k ON <predicate>  with only
   t and k in scope. The hop cannot be written without a subquery, and
   arch.usp_AssertSafeSqlExpression refuses subqueries (50400). Someone tried
   exactly that on 2026-09-15, by direct INSERT past the API gate, and the RUN
   job failed on its first ORDER batch.

   So t_pick_container cannot be deleted by this set on real data, and - checked
   the same way - it does NOT need to be: sys.foreign_keys lists six tables
   referencing t_order, and t_pick_container is not one of them. The ORDER set
   deletes orders cleanly without it.

   The container family therefore stays in the source, deliberately, until it
   gets a set of its own anchored on t_pick_container with keys
   (container_id, wh_id). Two decisions for the data-model owner before that set
   is written: the gate (container status is NOT a proxy for order completion -
   575 of 1 039 ACTIVE containers sit on SHIPPED orders; actual_ship_date is the
   honest cutoff) and the double ownership of t_container_master, which has FKs
   to both t_order and t_pick_container.

   On an instance where an earlier revision of this script already added
   t_pick_container, run 57_order_set_container_family.sql to take it out.
   =========================================================================== */
PRINT 't_pick_container: NOT added to AAD_ORDER_ARCH - see the note above (FK children the set cannot express; no FK to t_order, so not needed).';
GO

/* ===========================================================================
   1b) THE FK CHILDREN OF t_order THAT THE ORIGINAL ORDER SET DID NOT HAVE
   ===========================================================================
   sys.foreign_keys lists six tables referencing t_order. Three of them were not
   in the set: t_container_master, t_order_status, t_geek_pick_order. On real
   data the t_order delete fails on the FK the moment one of them holds a row for
   an archived order - and on the reference data they hold 1 010 / 751 / 0.

   These three appeared on the reference instance on 2026-09-15 by direct INSERT,
   with no audit record. This section adds them the proper way, through the API
   (which also runs the safety gate on the join), so a fresh deployment is
   FK-complete without anyone having to remember.

   Conditional on the table existing in the WMS schema: t_geek_pick_order in
   particular is a site extension (Geek+ robots) and will not be everywhere. A
   missing table is reported and skipped, not treated as an error. Idempotent:
   a table already configured for the set is left alone.

   DeleteOrder: 43 t_container_master (before t_pick_container's old slot 45, in
   case an old revision left it there), 47 t_order_status, 48 t_geek_pick_order,
   all before the anchor t_order at 50.
   =========================================================================== */
DECLARE @PcOrder2 sysname       = N'AAD_ORDER_ARCH';
DECLARE @By2      nvarchar(256) = N'kam-deploy';
DECLARE @Rsn2     nvarchar(1000) = N'FK child of t_order (sys.foreign_keys). Without it the t_order delete fails on real data. Added 2026-09-16 after the first real-data run exposed the gap.';
DECLARE @Cs2      bigint = NULL;
DECLARE @Os2      int;
DECLARE @tbl      sysname, @ord int;

DECLARE @fkKids TABLE (SourceTable sysname, DeleteOrder int);
INSERT @fkKids VALUES (N't_container_master', 43), (N't_order_status', 47), (N't_geek_pick_order', 48);

DECLARE cKids CURSOR LOCAL FAST_FORWARD FOR SELECT SourceTable, DeleteOrder FROM @fkKids ORDER BY DeleteOrder;
OPEN cKids; FETCH NEXT FROM cKids INTO @tbl, @ord;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF OBJECT_ID(QUOTENAME(N'$(WmsDb)') + N'.dbo.' + QUOTENAME(@tbl), N'U') IS NULL
        PRINT '  ' + @tbl + ': not present in $(WmsDb) - skipped (site extension not installed here).';
    ELSE IF EXISTS (SELECT 1 FROM arch.ObjectSpec o JOIN arch.Process p ON p.ProcessId = o.ProcessId
                    WHERE p.ProcessCode = @PcOrder2 AND o.SourceTable = @tbl)
        PRINT '  ' + @tbl + ': already configured for ' + @PcOrder2 + ' - left alone.';
    ELSE
    BEGIN
        SET @Os2 = NULL;
        EXEC arch.usp_Api_SaveObjectSpec
            @ObjectSpecId             = @Os2 OUTPUT,
            @ProcessCode              = @PcOrder2,
            @RequestedBy              = @By2,
            @ChangeReason             = @Rsn2,
            @SourceSchema             = N'dbo',
            @SourceTable              = @tbl,
            @DeleteOrder              = @ord,
            @DeleteMode               = 1,
            @TimestampExpr            = NULL,
            @JoinToAnchorPredicateSql = N't.order_number = k.Key1 AND t.wh_id = k.Key2',
            @AdditionalWhereSql       = NULL,
            @ArchiveSchema            = N'{SourceDb}',
            @ArchiveTable             = NULL,
            @RequireArchiveForDelete  = 1,
            @NaturalKeyLabel          = N'ORDER_NUMBER',
            @ConfigChangeSetId        = @Cs2 OUTPUT;
        PRINT '  ' + @tbl + ': added at DeleteOrder ' + CONVERT(varchar(4), @ord) + ' (ObjectSpecId ' + CONVERT(varchar(10), @Os2) + ').';
    END;

    -- Register the JOIN index requirement either way - including for a table that
    -- was already configured, since an earlier revision added these three without
    -- one. DETECT whether a supporting index exists rather than asserting it: the
    -- reference schema happens to have (wh_id, order_number) leading on all three,
    -- but a customer site may not, and the delete join would then scan the table
    -- once per batch. We never create the index - the house rule holds - we record
    -- the requirement so the console shows it and the DBA can act.
    IF OBJECT_ID(QUOTENAME(N'$(WmsDb)') + N'.dbo.' + QUOTENAME(@tbl), N'U') IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM arch.IndexRequirement ir JOIN arch.Process p ON p.ProcessId = ir.ProcessId
                       WHERE p.ProcessCode = @PcOrder2 AND ir.SourceTable = @tbl AND ir.RequirementType = N'JOIN')
    BEGIN
        DECLARE @idxName sysname, @idxNote nvarchar(1000), @IrOs int = NULL;
        DECLARE @probe nvarchar(max) = N'
            SELECT TOP 1 @n = i.name
            FROM ' + QUOTENAME(N'$(WmsDb)') + N'.sys.indexes i
            WHERE i.object_id = OBJECT_ID(N''' + N'$(WmsDb)' + N'.dbo.' + @tbl + N''')
              AND i.type > 0
              AND EXISTS (SELECT 1 FROM ' + QUOTENAME(N'$(WmsDb)') + N'.sys.index_columns ic
                          JOIN ' + QUOTENAME(N'$(WmsDb)') + N'.sys.columns c
                            ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                          WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id
                            AND ic.is_included_column = 0 AND ic.key_ordinal = 1 AND c.name = N''wh_id'')
              AND EXISTS (SELECT 1 FROM ' + QUOTENAME(N'$(WmsDb)') + N'.sys.index_columns ic
                          JOIN ' + QUOTENAME(N'$(WmsDb)') + N'.sys.columns c
                            ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                          WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id
                            AND ic.is_included_column = 0 AND ic.key_ordinal = 2 AND c.name = N''order_number'');';
        SET @idxName = NULL;
        EXEC sys.sp_executesql @probe, N'@n sysname OUTPUT', @n = @idxName OUTPUT;

        SET @idxNote = CASE
            WHEN @idxName IS NOT NULL
                THEN N'Satisfied by ' + @idxName + N' - (wh_id, order_number) is its leading prefix, so the delete join seeks. No index is needed from the schema owner.'
            ELSE N'MISSING - no index on this table leads with (wh_id, order_number), so the delete join will scan it once per batch. Suggested for the schema owner: CREATE NONCLUSTERED INDEX IX_' + @tbl + N'_wh_order ON dbo.' + @tbl + N' (wh_id, order_number). NEVER created by this package - see the house rule in 08_source_indexes.sql.'
            END;

        EXEC arch.usp_Api_SaveIndexRequirement
            @IndexRequirementId = @IrOs OUTPUT,
            @ProcessCode        = @PcOrder2,
            @RequestedBy        = @By2,
            @ChangeReason       = @Rsn2,
            @RequirementType    = N'JOIN',
            @SourceSchema       = N'dbo',
            @SourceTable        = @tbl,
            @KeyColumnsCsv      = N'wh_id,order_number',
            @IsMandatory        = 0,
            @Notes              = @idxNote,
            @ConfigChangeSetId  = @Cs2 OUTPUT;
        PRINT '  ' + @tbl + ': index requirement recorded - ' + CASE WHEN @idxName IS NOT NULL THEN N'satisfied by ' + @idxName ELSE N'*** MISSING, hand to the DBA ***' END;
    END;
    FETCH NEXT FROM cKids INTO @tbl, @ord;
END;
CLOSE cKids; DEALLOCATE cKids;

-- Prove FK-completeness the same way 57 does: every table with an FK into
-- t_order must now be in the set. A MISSING here is a run-time FK failure later.
SELECT Section = 'FK_COMPLETE_ORDER',
       FkChild = OBJECT_NAME(fk.parent_object_id, DB_ID(N'$(WmsDb)')),
       InSet = CASE WHEN EXISTS (SELECT 1 FROM arch.ObjectSpec o JOIN arch.Process p ON p.ProcessId = o.ProcessId
                                  WHERE p.ProcessCode = @PcOrder2
                                    AND o.SourceTable = OBJECT_NAME(fk.parent_object_id, DB_ID(N'$(WmsDb)')))
                    THEN 'yes' ELSE '*** MISSING ***' END
FROM [$(WmsDb)].sys.foreign_keys fk
WHERE fk.referenced_object_id = OBJECT_ID(N'$(WmsDb).dbo.t_order')
GROUP BY OBJECT_NAME(fk.parent_object_id, DB_ID(N'$(WmsDb)'))
ORDER BY 2;
GO

/* ===========================================================================
   2) t_pick_task_uom -> AAD_PICKDETAIL_ARCH
   ===========================================================================
   Per-pick cartonisation detail: how one pick's quantity maps to uom and pattern
   inside a carton. pick_id is bigint NOT NULL, the same type as
   t_pick_detail.pick_id, so the predicate covers every row - there is no orphan
   class here, unlike t_pick_container.

   It has no order_number at all, so PICKDETAIL is the only set it could join to.
   Across the whole database only two modules reference it (usp_afo_hold_wave and
   usp_afa_hold_shipment) and both only delete it while un-releasing work. Nothing
   ever SELECTs it. After a normal pick-and-ship the rows are dead weight.

   DeleteOrder 15: before the anchor t_pick_detail (20), alongside t_allocation.
   =========================================================================== */
DECLARE @PcPick sysname        = N'AAD_PICKDETAIL_ARCH';
DECLARE @By2    nvarchar(256)  = N'kam-deploy';
DECLARE @RsnPu  nvarchar(1000) = N'Per-pick cartonisation detail. Found by the data-model analysis: nothing in the WMS reads it and only the un-release paths delete it, so it survives every completed pick.';
DECLARE @CsId2  bigint = NULL;
DECLARE @OsId2  int    = NULL;

IF EXISTS (SELECT 1 FROM arch.ObjectSpec o JOIN arch.Process p ON p.ProcessId = o.ProcessId
           WHERE p.ProcessCode = @PcPick AND o.SourceTable = N't_pick_task_uom')
    PRINT '  t_pick_task_uom: already configured for AAD_PICKDETAIL_ARCH - left alone.';
ELSE
EXEC arch.usp_Api_SaveObjectSpec
    @ObjectSpecId             = @OsId2 OUTPUT,
    @ProcessCode              = @PcPick,
    @RequestedBy              = @By2,
    @ChangeReason             = @RsnPu,
    @SourceSchema             = N'dbo',
    @SourceTable              = N't_pick_task_uom',
    @DeleteOrder              = 15,
    @DeleteMode               = 1,
    @TimestampExpr            = NULL,
    @JoinToAnchorPredicateSql = N't.pick_id = k.Key1',
    @AdditionalWhereSql       = NULL,
    @ArchiveSchema            = N'{SourceDb}',
    @ArchiveTable             = NULL,
    @RequireArchiveForDelete  = 1,
    @NaturalKeyLabel          = N'PICK_ID',
    @ConfigChangeSetId        = @CsId2 OUTPUT;

-- This one is NOT satisfied, and the requirement says so. The table is a HEAP
-- with no primary key, and its only index ui_pick_task_uom leads on
-- (wh_id, cartonization_batch_id, planned_actual, line_number, pick_id) - pick_id
-- is the FIFTH key column, so a join on pick_id alone cannot seek it and will scan
-- the heap once per batch. Registered as MISSING for the schema owner to action,
-- exactly as was done for t_pack and t_work_q_dependency. Since the process has
-- RequireSupportingIndex = 1 this will surface as a validation WARN until an index
-- exists - which is the intended behaviour, not a defect.
DECLARE @IrId2 int = NULL;
EXEC arch.usp_Api_SaveIndexRequirement
    @IndexRequirementId = @IrId2 OUTPUT,
    @ProcessCode        = @PcPick,
    @RequestedBy        = @By2,
    @ChangeReason       = @RsnPu,
    @RequirementType    = N'JOIN',
    @SourceSchema       = N'dbo',
    @SourceTable        = N't_pick_task_uom',
    @KeyColumnsCsv      = N'pick_id',
    @IsMandatory        = 0,
    @Notes              = N'MISSING - t_pick_task_uom is a heap whose only index ui_pick_task_uom has pick_id as its fifth key column, so the delete join scans. Suggested for the schema owner: CREATE NONCLUSTERED INDEX IX_t_pick_task_uom_pick_id ON dbo.t_pick_task_uom (pick_id). NEVER created by this package - see the house rule in 08_source_indexes.sql.',
    @ConfigChangeSetId  = @CsId2 OUTPUT;
GO

PRINT '';
PRINT '26_add_pick_order_children: configuration applied.';
GO

/* ---------------------------- verification ------------------------------- */
SELECT Section = 'OBJECTSPEC', p.ProcessCode, os.DeleteOrder, os.SourceTable,
       os.JoinToAnchorPredicateSql, os.RequireArchiveForDelete, os.NaturalKeyLabel
FROM arch.ObjectSpec os
JOIN arch.Process p ON p.ProcessId = os.ProcessId
WHERE p.ProcessCode IN (N'AAD_ORDER_ARCH', N'AAD_PICKDETAIL_ARCH')
ORDER BY p.ProcessCode, os.DeleteOrder;

-- The anchor must still be last in its set. If a DeleteOrder collision pushed it
-- out of last place the set would delete its header before its children.
SELECT Section = 'ANCHOR_IS_LAST', p.ProcessCode, p.AnchorTable,
       AnchorDeleteOrder = a.DeleteOrder,
       MaxDeleteOrder    = (SELECT MAX(os2.DeleteOrder) FROM arch.ObjectSpec os2 WHERE os2.ProcessId = p.ProcessId),
       Verdict = CASE WHEN a.DeleteOrder = (SELECT MAX(os2.DeleteOrder) FROM arch.ObjectSpec os2 WHERE os2.ProcessId = p.ProcessId)
                      THEN 'ok - anchor deleted last' ELSE '*** ANCHOR IS NOT LAST ***' END
FROM arch.Process p
JOIN arch.ObjectSpec a ON a.ProcessId = p.ProcessId AND a.SourceTable = p.AnchorTable
WHERE p.ProcessCode IN (N'AAD_ORDER_ARCH', N'AAD_PICKDETAIL_ARCH')
ORDER BY p.ProcessCode;

-- No table may appear in two sets: two processes deleting the same rows on
-- different cutoffs is the one configuration error this package cannot recover
-- from. 25_seed_document_sets.sql makes the same check across all five sets.
SELECT Section = 'OVERLAP_CHECK', os.SourceTable, Sets = COUNT(DISTINCT os.ProcessId),
       Which = STUFF((SELECT N', ' + p2.ProcessCode
                      FROM arch.ObjectSpec os2 JOIN arch.Process p2 ON p2.ProcessId = os2.ProcessId
                      WHERE os2.SourceTable = os.SourceTable
                      ORDER BY p2.ProcessCode FOR XML PATH('')), 1, 2, '')
FROM arch.ObjectSpec os
GROUP BY os.SourceTable
HAVING COUNT(DISTINCT os.ProcessId) > 1;

IF @@ROWCOUNT = 0 PRINT 'OVERLAP_CHECK: no table is configured in more than one set.';
GO
